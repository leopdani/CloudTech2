package br.usjt.cloudtech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CloudtechApplication {

	public static void main(String[] args) {
		SpringApplication.run(CloudtechApplication.class, args);
	}
 
}
