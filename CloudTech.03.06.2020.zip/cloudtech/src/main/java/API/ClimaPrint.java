package API;

public class ClimaPrint {
	public static void main(String args[]) {
		Clima clima = new Clima();

		Rest.doHttpGet();
		
		Headline.ReadJSON(clima);
		DailyForecasts.ReadJSON(clima);
		
		System.out.println("texto: " + clima.headline.text);
		System.out.println("seriedade: " + clima.headline.severity);
		System.out.println("maxima: " + (int)clima.dailyforecasts.temperature.maximun.value);
		System.out.println("minima: " + (int)clima.dailyforecasts.temperature.minimun.value);
	}
}


 