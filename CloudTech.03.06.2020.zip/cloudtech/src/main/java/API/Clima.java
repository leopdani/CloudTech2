package API;


import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.sun.el.parser.ParseException;

public class Clima {
	public Headline headline;
	public DailyForecasts dailyforecasts;
	
	public Clima() {
		
	}
	
	public Headline getHeadline() {
		return headline;
	}
	public void setHeadline(Headline headline) {
		this.headline = headline;
	}
	public DailyForecasts getDailyforecasts() {
		return dailyforecasts;
	}
	public void setDailyforecasts(DailyForecasts dailyforecasts) {
		this.dailyforecasts = dailyforecasts;
	}
		
}

class Headline extends Clima{ 
	public String text;
	public long severity;
	
	public Headline() {
		
		
	}
	
	public static void ReadJSON(Clima clima){

        Headline headline = new Headline();
        JSONObject jsonObject;
        JSONParser parser = new JSONParser();
        Map hl;

        try {
            jsonObject = (JSONObject) parser.parse(new FileReader("saida.json"));
            hl = (Map) jsonObject.get("Headline");
            headline.text = (String) hl.get("Text");
            headline.severity = (Long) hl.get("Severity");
            

            clima.setHeadline(headline);

        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        } catch (org.json.simple.parser.ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        

    }
	
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public long getSeverity() {
		return severity;
	}
	public void setSeverity(long severity) {
		this.severity = severity;
	}
	
}
class DailyForecasts extends Clima {
	public Temperature temperature;

	public DailyForecasts() {
		
	}
	public static void ReadJSON(Clima clima) {

        Temperature temperature = new Temperature();
        DailyForecasts dailyForecasts = new DailyForecasts();
        JSONObject jsonObject = null, tempList;
        JSONParser parser = new JSONParser();
        JSONArray  dailyFor, sources;
        Map temp, min, max, dia, noite;
        Maximun maximun = new Maximun();
        Minimun minimun = new Minimun();
        double ma, mi;

        try {
            jsonObject = (JSONObject) parser.parse(new FileReader("saida.json"));
            dailyFor = (JSONArray) jsonObject.get("DailyForecasts");
            tempList = (JSONObject) dailyFor.get(0);
            temp = (Map) tempList.get("Temperature");
            min = (Map) temp.get("Minimum");
            mi = (Double) min.get("Value");
            minimun.value = Temperature.getCelsius(mi);
            max = (Map) temp.get("Maximum");
            ma = (Double) max.get("Value");
            maximun.value = Temperature.getCelsius(ma);
            
            temperature.setMaximun(maximun);
            temperature.setMinimun(minimun);
            

            dailyForecasts.setTemperature(temperature);
            clima.setDailyforecasts(dailyForecasts);

        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (org.json.simple.parser.ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
    }


    public void setTemperature(Temperature temperature) {
        this.temperature = temperature;
    }
}
	
class Temperature extends DailyForecasts {
	public Maximun maximun;
	public Minimun minimun;
	
	public Temperature() {
		
	}

	public void setMaximun(Maximun maximun) {
		this.maximun = maximun;
	}

	public void setMinimun(Minimun minimun) {
		this.minimun = minimun;
	}
	
	public static double getCelsius(double F){
        return (F-32.0)*(5.0/9.0);
    }
}

class Maximun extends Temperature{
	public double value;
	
	public Maximun() {
		
	}
	
}

class Minimun extends Temperature{
	public double value;

	public Minimun() {
		
	}
	
	
}


